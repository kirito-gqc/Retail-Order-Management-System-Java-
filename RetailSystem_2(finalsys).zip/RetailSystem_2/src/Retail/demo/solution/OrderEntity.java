/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

/**
 *
 * @author nitro 5
 */
public class OrderEntity {
    
    
    private String CustomerID;
    
    private String ProductName;
    
    private String ProductPrice;
    
    private String Quantity;
    
    private String Totalprice;

    public String getTotalprice() {
        return Totalprice;
    }

    public void setTotalprice(String Totalprice) {
        this.Totalprice = Totalprice;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(String ProductPrice) {
        this.ProductPrice = ProductPrice;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }
    


    
    
    
    
}
