/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

/**
 *
 * @author Acer
 */
public class CustomerEntity {
    public CustomerEntity(){
        super();
    }
    
    private int CustomerID;
    
    public void setCustomerID(int CustomerID)
    {
        this.CustomerID = CustomerID;
    }
    public int getCustomerID()
    {
        return CustomerID;
    } 
    
    private String CustomerName;
    
    public void setCustomerName(String CustomerName)
    {
        this.CustomerName = CustomerName;
    }
    public String getCustomerName()
    {
        return CustomerName;
    } 
    
    private String Email;
    
    public void setEmail(String Email)
    {
        this.Email = Email;
    }
    public String getEmail()
    {
        return Email;
    }
    
    private String Address;
    
    public void setAddress(String Address)
    {
        this.Address = Address;
    }
    public String getAddress()
    {
        return Address;
    }
    
    private String Phone;
    
    public void setPhone(String Phone)
    {
        this.Phone = Phone;
    }
    public String getPhone()
    {
        return Phone;
    }
    
    private String Password;
    
    public void setPassword(String Password)
    {
        this.Password=Password;
    }
    public String getPassword()
    {
        return Password;
    }
    
}
