/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

import Retail.demo.solution.OrderEntity;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author nitro 5
 */
public class OrderOperation {

    String file = "cart.txt";

    public int AddOrder(OrderEntity orderEntity) {
        Boolean isOrderAdded = false;
        int OrderIndex = GetLastIndex() + 1;
        try {
            FileWriter fw = new FileWriter(file, true);
            fw.write(orderEntity.getCustomerID() + "," + orderEntity.getProductName() + "," + orderEntity.getProductPrice() + "," + orderEntity.getQuantity()+ "," + orderEntity.getTotalprice() + System.getProperty("line.separator"));
            fw.close();
            isOrderAdded = true;
        } catch (IOException ex) {
            isOrderAdded = false;
        } catch (Exception ex) {
            isOrderAdded = false;
        }
        return OrderIndex;
    }

    public int GetLastIndex() {
        int lastID = 0;
        if (isDataExists()) {
            try {
                Path path = Paths.get(file);
                byte[] bytes = Files.readAllBytes(path);
                List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
                String[] arrOfStr = allLines.get(allLines.size() - 1).split(",");
                lastID = Integer.parseInt(arrOfStr[0]);
            } catch (IOException ex) {
            }
        }
        return lastID;
    }

    public boolean isDataExists() {
        boolean isExists = false;
        try {
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            if (allLines.size() > 0 && !allLines.get(0).equals("")) {
                isExists = true;
            }
        } catch (IOException ex) {

        }
        return isExists;
    }

}
