/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author nitro 5
 */
public class CustomerCartManageOperation {

    String file = "cart.txt";

    public Boolean UpdateOrder(OrderEntity orderEntity) {
        Boolean isUpdated = false;
        try {

            String Content = "";
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines) {
                if (!data.equals("")) {
                    String[] arrOfStr = data.split(",");
                    if ((arrOfStr[0]).equals(orderEntity.getCustomerID())) {
                        Content = Content + (orderEntity.getCustomerID() + "," + orderEntity.getProductName() + "," + orderEntity.getProductPrice() + "," + orderEntity.getQuantity() + "," + orderEntity.getTotalprice() + System.getProperty("line.separator"));
                    
                       
                    } else {
                        Content = Content + (arrOfStr[0] + "," + arrOfStr[1] + "," + arrOfStr[2] + "," + arrOfStr[3] + "," + arrOfStr[4] + System.getProperty("line.separator"));
                    }
                }
            }
            File file1 = new File(file);
            file1.delete();
            file1.createNewFile();
            FileWriter fw = new FileWriter(file, true);
            fw.write(Content);
            fw.close();
            isUpdated = true;
        } catch (IOException ex) {
            isUpdated = false;
        }
        return isUpdated;
    }

    public Boolean DeleteOrder(int CustomerID) {
        Boolean isDeleted = false;
        try {
            String fileContent = "";
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines) {
                if (!data.equals("")) {
                    String[] arrOfStr = data.split(",");
                    if (Integer.parseInt(arrOfStr[0]) == CustomerID) {

                    } else {
                        fileContent = fileContent + (arrOfStr[0] + "," + arrOfStr[1] + "," + arrOfStr[2] + "," + arrOfStr[3] + "," + arrOfStr[4] + System.getProperty("line.separator"));
                    }
                }
            }
            File file2 = new File(file);
            file2.delete();
            file2.createNewFile();
            FileWriter fw = new FileWriter(file, true);
            fw.write(fileContent);
            fw.close();
            isDeleted = true;
        } catch (IOException ex) {
            isDeleted = false;
        }
        return isDeleted;
    }

}
